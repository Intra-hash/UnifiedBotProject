import app from './server.js';
import client from './bot.js';

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


export const handler = async (event) => {
  client.login(process.env.SECRET_KEY);
  return {
    statusCode: 200,
    body: JSON.stringify({ message: "Bot is running" }),
  };
};